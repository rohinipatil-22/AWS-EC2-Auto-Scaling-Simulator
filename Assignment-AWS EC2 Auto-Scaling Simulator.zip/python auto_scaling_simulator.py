import json

# Scaling thresholds
SCALE_UP_THRESHOLD = 70  # Scale up if CPU > 70%
SCALE_DOWN_THRESHOLD = 20  # Scale down if CPU < 20%
INITIAL_INSTANCES = 2  # Start with 2 instances

def scale_instances(current_instances, avg_cpu_utilization):
    """
    Determine whether to scale up or scale down based on average CPU utilization.

    
    :param current_instances: Current number of EC2 instances
    :param avg_cpu_utilization: Average CPU utilization percentage
    :return: new number of instances
    """
    if avg_cpu_utilization > SCALE_UP_THRESHOLD:
        return current_instances + 1  # Scale up
    elif avg_cpu_utilization < SCALE_DOWN_THRESHOLD and current_instances > 1:
        return current_instances - 1  # Scale down (but do not go below 1 instance)
    return current_instances  # No scaling needed

def read_metrics_from_json(json_file):
    """
    Read CPU utilization metrics from a JSON file.

    :param json_file: Path to the JSON file containing CPU utilization data
    :return: List of dictionaries containing time and CPU utilization data
    """
    with open(json_file, 'r') as file:
        return json.load(file)

def simulate_auto_scaling(metrics):
    """
    Simulate the auto-scaling of EC2 instances based on CPU utilization metrics.

    :param metrics: List of CPU utilization data at different time intervals
    """
    current_instances = INITIAL_INSTANCES
    for entry in metrics:
        time = entry['time']
        cpu_utilization = entry['cpu_utilization']
        
        # Calculate the average CPU utilization (in case of multiple readings per time interval)
        avg_cpu_utilization = sum(cpu_utilization) / len(cpu_utilization)
        
        # Make scaling decision
        current_instances = scale_instances(current_instances, avg_cpu_utilization)
        
        # Output the results for this interval
        print(f"Time: {time}, Avg CPU Utilization: {avg_cpu_utilization:.2f}%, Instances: {current_instances}")

if __name__ == "__main__":
    # Path to your input JSON file
    json_file_path = 'metrics.json'
    
    try:
        # Read the metrics from the JSON file
        metrics = read_metrics_from_json(json_file_path)
        
        # Simulate the auto-scaling process
        simulate_auto_scaling(metrics)
    except FileNotFoundError:
        print(f"Error: The file '{json_file_path}' was not found.")
    except json.JSONDecodeError:
        print(f"Error: The file '{json_file_path}' is not a valid JSON file.")
